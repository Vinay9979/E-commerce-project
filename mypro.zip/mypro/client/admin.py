from django.contrib import admin
from client.models import Billingaddress
# Register your models here.

admin.register(Billingaddress)
