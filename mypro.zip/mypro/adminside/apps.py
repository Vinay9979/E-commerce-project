from django.apps import AppConfig


class AdminsideConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'adminside'
